using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    public class FundingApplication
    {
        [Key, StringLength(20)]
        public string Id { get; set; }

        public Employee? Employee { get; set; }

        [Column(TypeName = "Date")]
        public DateTime? Date { get; set; }

        public int? Status { get; set; }

        [StringLength(100)]
        public string Opinion { get; set; }

        [Required]
        public Bill Bill { get; set; }
    }
}