using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    public class EquipmentLease//�豸����
    {
        [Key, StringLength(20)]
        public string Id { get; set; }//���

        public Employee? Employee { get; set; }//�Խӹ���ID����FKԱ��id

        [Column(TypeName = "Date")]
        public DateTime? OrderDate { get; set; }//��������

        [StringLength(20)]
        public string? OrderStatus { get; set; }//����״̬

        [StringLength(20)]
        public string? PaymentStatus { get; set; }//֧��״̬

        public Customer? Customer { get; set; }

        [Required]
        public Bill Bill { get; set; }
    }
}