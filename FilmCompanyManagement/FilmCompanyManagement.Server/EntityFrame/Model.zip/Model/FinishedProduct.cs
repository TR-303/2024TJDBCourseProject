using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    public class FinishedProduct//��Ƭ���򶩵�
    {
        [Key, StringLength(20)]
        public string Id { get; set; }//�������

        [StringLength(20)]
        public string? Type { get; set; }//��������

        [Column(TypeName = "Date")]
        public DateTime? Date { get; set; }//��������

        [StringLength(20)]
        public string? OrderStatus { get; set; }//����״̬

        [StringLength(20)]
        public string? PaymentStatus { get; set; }//֧��״̬

        public File? File { get; set; }

        public Customer? Customer { get; set; }

        [Required]
        public Bill Bill { get; set; }
    }
}