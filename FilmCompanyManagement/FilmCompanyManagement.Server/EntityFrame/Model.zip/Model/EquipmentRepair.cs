using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    public class EquipmentRepair
    {
        [Key, StringLength(20)]
        public string Id { get; set; }

        [Required]
        public PhotoEquipment PhotoEquipment { get; set; }

        [StringLength(100)]
        public string? Description { get; set; }

        [Required]
        public Bill Bill { get; set; }

        public int? Status { get; set; }

        [StringLength(100)]
        public string Opinion {  get; set; }
    }
}