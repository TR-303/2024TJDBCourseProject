using System.ComponentModel.DataAnnotations;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    // �洢�豸
    public class StorageEquipment
    {
        [Key, StringLength(20)]
        public string Id { get; set; }

        [StringLength(20)]
        public string? Name { get; set; }

        [StringLength(20)]
        public string? Model { get; set; }

        public int? Count { get; set; }

        // �Զ��ϵFiles
        public ICollection<File> Files { get; set; }
    }
}