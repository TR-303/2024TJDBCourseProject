using Microsoft.AspNetCore.Antiforgery;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    public class Bill
    {
        [Key, StringLength(20)]
        public string Id { get; set; }

        [Required, Column(TypeName = "decimal(12, 2)")]
        public decimal Amount { get; set; }

        [StringLength(20)]
        public string? Type { get; set; }

        [Column(TypeName = "Date")]
        public DateTime? Date { get; set; }

        // �Ե���ϵAccounts
        public Account? Account { get; set; }
    }
}