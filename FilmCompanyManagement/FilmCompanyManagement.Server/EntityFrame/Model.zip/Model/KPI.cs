﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmCompanyManagement.Server.EntityFrame.Models
{
    [Table("KPI")]
    public class KPI
    {
        [Key, StringLength(20)]
        public string Id { get; set; }

        public Project? Project { get; set; }

        [Required, Column(TypeName = "Date")]
        public DateTime Date { get; set; } // 绩效评定时间

        [Column(TypeName = "NUMBER(1)")]
        public bool? Result { get; set; } // 评定结果，true为通过，false为不通过

        public Employee? Judger { get; set; } // 导航属性，追究评定者信息
    }
}
